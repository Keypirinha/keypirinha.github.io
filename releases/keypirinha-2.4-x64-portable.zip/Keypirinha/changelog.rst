Change log of `Keypirinha`_


v2.4 - 2016-03-24
=================

**CAUTION**
-----------
* The default value of the ``launch_at_startup`` setting has been changed from
  ``yes`` to ``no`` to be less invasive. You may need to update your
  configuration if you want Keypirinha to keep being launched at startup.
* WebSearch package: the default value of the ``new_window`` setting in the
  ``[defaults]`` section has been changed from ``yes`` to ``no`` to comply to
  default system preferences.

Added
-----
* The *Reload Configuration* command and menu to reload all configuration files
  (application and plugins), and to clear the runtime icons cache
* Non-existent files referenced by items in the history are now filtered out
  from search results, but **kept** in history (as it was the case already).
  Related setting: ``exclude_nonexistent_remote_files``.
* Docs: some questions in the :doc:`faq` chapter

Fixed
-----
* The *new_window* and *inognito/private_mode* settings (global and
  plugin-specific) where not working when Firefox was the system's default web
  browser `#25`_
* LaunchBox: web icons (Bookmarks, WebSearch, ... items) are now refreshed
  properly when the ``web_browser`` setting is changed `#26`_
* Apps package: made ``extra_paths``, env ``PATH`` and *Start Menu* scans more
  bullet-proof in case an unreadable file/folder gets on its way (`#19`_,
  `#29`_)
* Bookmarks: Firefox bookmarks provider could not read Firefox's
  ``profiles.ini`` file when its nomenclature format was not exactly the
  expected one `#30`_

Changed
-------
* LaunchBox: last executed action is now pre-selected in the ACTIONS list. If
  user skips the ACTIONS list, item will be executed with the default action
* The default value of the ``launch_at_startup`` setting has been changed from
  ``yes`` to ``no`` to be less invasive
* WebSearch package: the default value of the ``new_window`` setting in the
  ``[defaults]`` section has been changed from ``yes`` to ``no`` to comply to
  default system preferences.
* Minor corrections and improvements

API: Changed
------------
* :py:func:`keypirinha_util.raise_winerror` accepts a new optional ``msg``
  argument to override system's default message
* :py:func:`keypirinha_util.scan_directory` raises :py:exc:`OSError` instead
  of :py:exc:`IOError` to comply to Python 3.3 changes
* :py:func:`keypirinha_util.scan_directory` accepts new flag ``ABORT_ON_ERROR``


v2.3 - 2016-03-22
=================

**WARNING:** This version breaks compatibility of the
:py:meth:`keypirinha.Plugin.on_suggest` API with previous versions. If you are a
plugin developer or if you have modified the shipped packages, please ensure to
update your code before starting the application. Otherwise, just follow the
Install/Update instructions from the documentation.

Added
-----
* **New official package**: Everything (query `Everything`_ to search files and
  folders from Keypirinha).
* Docs: the :doc:`first` chapter has been stuffed with features that were
  undocumented so far.
* ``geometry`` settings in the ``[gui]`` and ``[console]`` sections. Note that
  due to this addition, default behavior **has changed** from previous release
  (i.e. from ``persistent`` to ``auto``)
* ``web_browser``, ``web_browser_new_window`` and
  ``web_browser_private_mode`` global settings `#12`_
* Bookmarks package: ``force_new_window``, ``bookmarks_files``, ``places_files``
  and ``favorites_dirs`` settings
* WebSearch package: *Metacritic* and *MSDN* sites in default configuration
* LaunchBox: the status bar shows the name of the owner package of the currently
  selected item

Fixed
-----
* Application was failing to launch if the value of an environment variable had
  a single dollar sign in it `#14`_
* The default text editor was launched too quickly, which could make its taskbar
  buttons not to be in order.
* The windows of the default text editor were not positioned properly on the
  screen when there were 3 or more configuration files to edit.

Changed
-------
* Drastically improved the speed of the internal logger in case of flooding
* Minor corrections, optimizations and improvements
* Docs: corrections and added some screen shots
* TaskSwitcher package: item is now kept in history, without its arguments
* Support chat room has moved

API: Changed
------------
* :py:meth:`keypirinha.Plugin.on_suggest` (**compatibility break**)


v2.2 - 2016-03-10
=================

Added
-----
* Bookmarks package: support for the Vivaldi web browser

Fixed
-----
* Restored compatibility with Windows 7 (Vista support dropped) `#13`_
* Detection of system's default web browser was incorrect on Windows 10
  (impacted packages: Bookmarks and WebSearch) `#11`_
* Bookmarks package: Firefox provider was making the plugin to fail in case user
  profile was not found.


v2.1 - 2016-03-09
=================

Added
-----
* **New official package**: Bookmarks (supports Chrome, Firefox and Internet
  Explorer)
* Position and size of the LaunchBox and the Console window are now persistent
  `#2`_
* ``always_on_top`` setting `#1`_
* ``max_height`` setting
* *Show Change Log* menu item and its *ChangeLog* catalog item
* *Online Documentation* menu item and the *Online Documentation* and
  *Online Help* (alias) catalog items
* Apps package: ``scan_start_menu`` and ``scan_env_path`` settings `#4`_
* Docs: *Update Procedure* section
* Docs: *Change Log* section
* Docs: *Credits* section

Changed
-------
* GUI: Improved readability by brightening default text colors `#6`_
* Calc package: the ``=`` item is not kept in History anymore

API: Added
----------
* :py:func:`keypirinha.exe_path`
* :py:func:`keypirinha.user_config_dir`
* :py:func:`keypirinha.package_cache_dir`
* :py:meth:`keypirinha.Plugin.id`
* :py:meth:`keypirinha.CatalogItem.valid`

API: Fixed
----------
* :py:func:`keypirinha.installed_package_dir` `#8`_
* :py:meth:`keypirinha.Plugin.create_action` was missing the ``data_bag``
  parameter `#7`_
* :py:meth:`keypirinha.Plugin.set_actions` and
  :py:meth:`keypirinha.Plugin.clear_actions` (due to `#7`_)
* :py:meth:`keypirinha.Plugin.get_package_cache_path` `#9`_

API: Deprecated
---------------
* :py:func:`keypirinha.packages_path` and :py:func:`keypirinha.package_path` are
  deprecated in favor of :py:func:`keypirinha.live_package_dir` to avoid
  confusion


v2.0 - 2016-03-01
=================
* First public release


v0 - 2013-05-21
===============
* Development started



.. _Keypirinha: http://keypirinha.com
.. _Everything: http://www.voidtools.com
.. _#1: https://github.com/Keypirinha/Keypirinha/issues/1
.. _#2: https://github.com/Keypirinha/Keypirinha/issues/2
.. _#4: https://github.com/Keypirinha/Keypirinha/issues/4
.. _#6: https://github.com/Keypirinha/Keypirinha/issues/6
.. _#7: https://github.com/Keypirinha/Keypirinha/issues/7
.. _#8: https://github.com/Keypirinha/Keypirinha/issues/8
.. _#9: https://github.com/Keypirinha/Keypirinha/issues/9
.. _#11: https://github.com/Keypirinha/Keypirinha/issues/11
.. _#12: https://github.com/Keypirinha/Keypirinha/issues/12
.. _#13: https://github.com/Keypirinha/Keypirinha/issues/13
.. _#14: https://github.com/Keypirinha/Keypirinha/issues/14
.. _#19: https://github.com/Keypirinha/Keypirinha/issues/19
.. _#25: https://github.com/Keypirinha/Keypirinha/issues/25
.. _#26: https://github.com/Keypirinha/Keypirinha/issues/26
.. _#29: https://github.com/Keypirinha/Keypirinha/issues/29
.. _#30: https://github.com/Keypirinha/Keypirinha/issues/30
