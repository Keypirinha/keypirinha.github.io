Change log of the `Keypirinha`_ project.


v2.2 - 2013-03-10
=================

Added
-----
* Bookmarks package: support for the Vivaldi web browser

Fixed
-----
* Restored compatibility with Windows 7 (Vista support dropped) `#13`_
* Detection of system's default web browser was incorrect on Windows 10
  (impacted packages: Bookmarks and WebSearch) `#11`_
* Bookmarks package: Firefox provider was making the plugin to fail in case user
  profile was not found.


v2.1 - 2016-03-09
=================

Added
-----
* **New official package**: Bookmarks (supports Chrome, Firefox and Internet
  Explorer)
* Position and size of the LaunchBox and the Console window are now persistent
  `#2`_
* ``always_on_top`` setting `#1`_
* ``max_height`` setting
* *Show Change Log* menu item and its *ChangeLog* catalog item
* *Online Documentation* menu item and the *Online Documentation* and
  *Online Help* (alias) catalog items
* Apps package: ``scan_start_menu`` and ``scan_env_path`` settings `#4`_
* Docs: *Update Procedure* section
* Docs: *Change Log* section
* Docs: *Credits* section

Changed
-------
* GUI: Improved readability by brightening default text colors `#6`_
* Calc package: the ``=`` item is not kept in History anymore

API: Added
----------
* :py:func:`keypirinha.exe_path`
* :py:func:`keypirinha.user_config_dir`
* :py:func:`keypirinha.package_cache_dir`
* :py:meth:`keypirinha.Plugin.id`
* :py:meth:`keypirinha.CatalogItem.valid`

API: Fixed
----------
* :py:func:`keypirinha.installed_package_dir` `#8`_
* :py:meth:`keypirinha.Plugin.create_action` was missing the ``data_bag``
  parameter `#7`_
* :py:meth:`keypirinha.Plugin.set_actions` and
  :py:meth:`keypirinha.Plugin.clear_actions` (due to `#7`_)
* :py:meth:`keypirinha.Plugin.get_package_cache_path` `#9`_

API: Deprecated
---------------
* :py:func:`keypirinha.packages_path` and :py:func:`keypirinha.package_path` are
  deprecated in favor of :py:func:`keypirinha.live_package_dir` to avoid
  confusion


v2.0 - 2016-03-01
=================
* First public release


v0 - 2013-05-21
===============
* Development started



.. _Keypirinha: http://keypirinha.com
.. _#1: https://github.com/Keypirinha/Keypirinha/issues/1
.. _#2: https://github.com/Keypirinha/Keypirinha/issues/2
.. _#4: https://github.com/Keypirinha/Keypirinha/issues/4
.. _#6: https://github.com/Keypirinha/Keypirinha/issues/6
.. _#7: https://github.com/Keypirinha/Keypirinha/issues/7
.. _#8: https://github.com/Keypirinha/Keypirinha/issues/8
.. _#9: https://github.com/Keypirinha/Keypirinha/issues/9
.. _#11: https://github.com/Keypirinha/Keypirinha/issues/11
.. _#13: https://github.com/Keypirinha/Keypirinha/issues/13
