#
# Keypirinha
# A semantic launcher for Windows.
# Copyright 2013-2016 Jean-Charles Lefebvre <polyvertex@gmail.com>
#

# CAUTION: DO NOT import the "keypirinha" module now!
# Python::init() wants to be the first to do it so it can warn the end-user
# properly in case there's something wrong with it. The "keypirinha" module is
# not compiled before being redistributed so it can easily be modified by a
# third-party.

import keypirinha_api
import sys
import os
import traceback
import types
import zipfile
import importlib

import builtins
import _thread
import threading


#-------------------------------------------------------------------------------
# Redirect standard outputs
class LogSink:
    def __init__(self, id):
        self.id = id

    def __del__(self):
        self.flush()

    def write(self, s):
        keypirinha_api.std_print(self.id, s)

    def flush(self):
        keypirinha_api.std_flush(self.id)

sys.stdout = LogSink(1)
sys.stderr = LogSink(2)


#-------------------------------------------------------------------------------
# Override some exit() and quit() functions in standard modules to avoid a
# crash.

def _no_exit(*args, **kwargs):
    raise NotImplementedError("exit() call trapped by Keypirinha")

builtins.exit = _no_exit
builtins.quit = _no_exit
os._exit = _no_exit
sys.exit = _no_exit
_thread.exit = _no_exit


#-------------------------------------------------------------------------------
# Trap the _thread.start_new_thread call so we can associate C threads and
# Python threads. Yes, Python rocks!
#
# NOTES:
# * Both _thread.start_new_thread() and _thread.start_new() point to the same C
#   function in Python's _threadmodule.c source file.
# * The 'threading' module keeps its own reference to _thread.start_new_thread.
# * The multiprocessing module does not seem to keep its own reference to
#   start_new_thread() (checked on 3.5.1).

def _thread_launchpad(*_, **bag):
    # CAUTION: we should avoid exceptions to be raised in this function...
    try:
        keypirinha_api.register_python_thread(0xca11ab1e, bag['parent_id'])
        bag['event'].set() # signals parent thread it can proceed
        bag['func'](*bag['args'], **bag['kwargs'])
    finally:
        keypirinha_api.unregister_python_thread(0xdeadBeef)

def _thread_create(function, args, kwargs={}):
    launchpad_bag = {
        'parent_id': _thread.get_ident(),
        'event': threading.Event(),
        'func': function,
        'args': args,
        'kwargs': kwargs}
    child_tid = _thread_create_impl(_thread_launchpad, (), launchpad_bag)
    if isinstance(child_tid, int) and child_tid != 0:
        launchpad_bag['event'].wait() # wait for child to have registered

# backup the reference to the real function
_thread_create_impl = _thread.start_new_thread

# install our hook
_thread.start_new_thread = _thread_create
_thread.start_new = _thread_create
threading._start_new_thread = _thread_create


#-------------------------------------------------------------------------------
# MultiZipImporter

def str_equal(a, b, case_sensitive):
    return a == b if case_sensitive else a.lower() == b.lower()

def str_less(a, b, case_sensitive):
    return a < b if case_sensitive else a.lower() < b.lower()

class MultiZipImporter:
    def __init__(self):
        self.loaders = []

    #def set_loaders(self, archives):
    #    self.loaders = []
    #    for path in archives:
    #        try:
    #            self.loaders.append(ZipLoader(path))
    #        except (FileNotFoundError, zipfile.BadZipFile) as e:
    #            print("Error loading " + path + ": " + str(e), file=sys.stderr)

    def set_package_loaders(self, package_name, case_sensitive, archives):
        # erase every loader related to this package
        self.loaders[:] = [
            loader for loader in self.loaders
            if not str_equal(loader.name, package_name, case_sensitive)]

        # load the desired archives
        new_loaders = []
        for path in archives:
            try:
                new_loaders.append(ZipLoader(path))
            except (FileNotFoundError, zipfile.BadZipFile) as e:
                print("Error loading " + path + ": " + str(e), file=sys.stderr)

        # insert the newly created loaders at the right offset
        if len(new_loaders) > 0:
            offset = 0
            for offset in range(len(self.loaders)):
                if not str_less(package_name, self.loaders[offset].name, case_sensitive):
                    break
            self.loaders[offset:offset] = new_loaders

    def find_module(self, fullname, path=None):
        if not path:
            for loader in self.loaders:
                if loader.name == fullname:
                    return loader

        for loader in self.loaders:
            if path == [loader.archive]:
                if loader.has(fullname):
                    return loader

        return None

class ZipLoader:
    def __init__(self, archive):
        self.archive = archive
        self.name = os.path.splitext(os.path.basename(archive))[0]
        self.packages = {""}
        self.contents = {"":""}

        zfile = zipfile.ZipFile(archive, 'r')
        subfiles = [entry.filename for entry in zfile.infolist()]

        for subfile in subfiles:
            subfile_base, subfile_ext = os.path.splitext(subfile)
            if subfile_ext != ".py":
                continue

            paths = subfile_base.split('/')
            if len(paths) > 0 and paths[len(paths) - 1] == "__init__":
                paths.pop()
                self.packages.add('.'.join(paths))

            try:
                self.contents['.'.join(paths)] = zfile.read(subfile).decode('utf-8')
            except UnicodeDecodeError:
                print("Unable to decode", subfile, "from", archive,
                    "(UTF-8 expected)")
                continue

            while len(paths) > 1:
                paths.pop()
                parent = '.'.join(paths)
                if parent not in self.contents:
                    self.contents[parent] = ""
                    self.packages.add(parent)

        zfile.close()

    def has(self, fullname):
        key = '.'.join(fullname.split('.')[1:])
        if key in self.contents:
            return True

        override_file = os.path.join(
            override_path,
            os.sep.join(fullname.split('.')) + '.py')
        if os.path.isfile(override_file):
            return True

        override_package = os.path.join(
            override_path,
            os.sep.join(fullname.split('.')))
        if os.path.isdir(override_package):
            return True

        return False

    def load_module(self, fullname):
        mod = sys.modules.setdefault(fullname, types.ModuleType(fullname))
        mod.__name__ = fullname
        mod.__file__ = self.archive + '/' + fullname
        mod.__path__ = [self.archive]
        mod.__loader__ = self

        key = '.'.join(fullname.split('.')[1:])

        if key in self.contents:
            source = self.contents[key]
            #source_path = key + ' in ' + self.archive
            source_path = os.sep.join((
                self.archive, os.sep.join(fullname.split('.')[1:]) + '.py'))

        is_pkg = key in self.packages

        try:
            override_file = os.path.join(
                override_path,
                os.sep.join(fullname.split('.')) + '.py')
            override_package_init = os.path.join(
                os.path.join(override_path, os.sep.join(fullname.split('.'))),
                '__init__.py')

            if os.path.isfile(override_file):
                with open(override_file, 'r') as f:
                    source = f.read()
                    source_path = override_file
            elif os.path.isfile(override_package_init):
                with open(override_package_init, 'r') as f:
                    source = f.read()
                    source_path = override_package_init
                    is_pkg = True
        except:
            pass

        if is_pkg:
            mod.__package__ = mod.__name__
        else:
            mod.__package__ = fullname.rpartition('.')[0]

        exec(compile(source, source_path, 'exec'), mod.__dict__)
        return mod

override_path = None
multi_importer = MultiZipImporter()
sys.meta_path.insert(0, multi_importer)

def reload_module(module_name):
    import keypirinha # late import, see comment at the top

    classes = []
    loaded_plugins = []

    # load or reload module
    try:
        if module_name in sys.modules:
            module = importlib.reload(sys.modules[module_name])
        else:
            module = importlib.import_module(module_name)
    except:
        traceback.print_exc()
        return []

    # do some introspection to find plugin classes
    for type_name in dir(module):
        try:
            plugin_class = module.__dict__[type_name]

            if (hasattr(plugin_class, '__bases__') and
                    plugin_class.__bases__ and
                    issubclass(plugin_class, keypirinha.Plugin)):
                classes.append(plugin_class)
        except:
            traceback.print_exc()

    # instantiate plugins
    if len(classes) > 0:
        for plugin_class in classes:
            try:
                plugin_obj = plugin_class()
                loaded_plugins.append(plugin_obj)
            except:
                traceback.print_exc()

    return loaded_plugins
