Change log of `Keypirinha`_


v2.9.2 - 2016-08-25
===================

Application
-----------
* Drastically optimized catalog search speed, most notably for big catalogs (up
  to 15 times faster)
* Drastically optimized catalog insertions/updates speed (up to 19 times faster)
  Note that this optimization only include the **indexing** part of the catalog
  building process. For example, that does not include the time plugin takes to
  actually build its list of items before pushing it to Keypirinha (especially
  files resulting from a hard-drive scan).
* Stability tested on large catalogs, containing up to 360,000 items

API
---
* Fixed a long-standing bug that prevented some resources to be found/loaded
  from a loose package `#111`_


v2.9.1 - 2016-08-23
===================

Application
-----------
* Search speed improved in some cases
* Application and packages are more permissive with file paths specified in
  configuration files that have unix-style separators (``/``) instead of
  windows-style ones (``\``)

Calc package
------------
* Added the ``rounding_precision`` setting
* Fixed: representation of floating point numbers `#104`_

Everything package
------------------
* Fixed: search items created by versions pre-2.9 were not working `#106`_

API
---
* Fixed :py:func:`keypirinha_util.shell_execute` that would fail if ``thing`` to
  execute was not a file (e.g. a URL) `#107`_
* :py:func:`keypirinha_util.file_attributes` inserts file path in exception's
  message (in case of error)


v2.9 - 2016-08-20
=================

Application
-----------
* Improved ``geometry`` setting for both LaunchBox and Console that also allows
  auto positioning according to current context: current working monitor, mouse
  current monitor or nearby mouse position. `#50`_
* Persistent geometry state for both LaunchBox and Console remembers positioning
  and sizing according to current monitors configuration. `#39`_
* LaunchBox's Y position is now automatically pushed up in order to have enough
  room to display at least one result item in case it was too low (only in
  *persistent* geometry mode)
* LaunchBox position is not forcefully restored to default anymore when user has
  moved it, until search is reset or window re-displayed
* LaunchBox now accepts the :kbd:`Alt+Left` shortcut to forcefully go back to
  the previous search step. The :kbd:`Alt+Right` shortcut is equivalent to
  :kbd:`Tab`. `#97`_
* LaunchBox displays the list of **history** items when :kbd:`Ctrl+Down` is
  pressed (or :kbd:`Down` if search state is clean) `#45`_
* ``.keypirinha-package`` files can now be updated at runtime `#73`_
* Fixed: Keypirinha does not rely on Windows' Shell anymore to get a folder
  icon and tries instead to get system's default from registry. `#89`_
* Keypirinha now tries to detect automatically the working directory of the
  launched applications `#101`_
* The ``editor``, ``terminal`` and ``web_browser`` application settings now
  accept shortcuts (link's arguments will be prepended to the extra ones
  specified in the setting value)
* Fixed a long standing bug that prevented Keypirinha to properly auto-detect
  configured editor's type (Atom, SublimeText, ...) via the ``editor`` setting

Calc package
------------
* Improved results readability: result is in item's label instead of its
  description
* Got rid of most common rounding precision problems that occured with floating
  point numbers `#98`_
* The ``=`` keyword can be specified as a prefix to query the plugin to evaluate
  the remaining of the typed string `#93`_
* Added the ``decimal_separator`` setting `#70`_
* Integer results are now automatically declined in multiple bases (i.e.
  decimal, hexadecimal, binary and octal)
* Currency formatting is now available (see the ``currency`` configuration
  section for more information)
* Added support for the ``bin()`` function `#96`_
* Added support for bitwise operators: ``|`` (or ``OR``), ``~`` (or ``XOR``) and
  ``&`` (or ``AND``)
* ``^`` is now an alias to the ``**`` (power of) operator
* Added support for Python's ``FloorDiv`` operator (``//``), also referred as
  *Integer Division*
* Added the ``ans`` constant that evaluates to the last valid result (reset to
  zero at Keypirinha's startup or when package is reloaded)
* Added support for Metric System suffixes (e.g. "K", "da", ...).
  See documentation for more info.
* Added support for suffixes of Orders of Magnitude of Data (e.g. "Ki", "Gi",
  ...). See documentation for more info.
* Upgraded the underlying Python module that is used to evaluate mathematical
  expressions (i.e. ``simpleeval``)

Everything package
------------------
* Added: predefined search patterns in the configuration file to ease the
  searches you do often (contributed by `@psistorm`_) `#94`_

FileBrowser package
-------------------
* Added the ``follow_shell_links`` setting

TaskSwitcher package
--------------------
* Fixed a bug that prevented the plugin to show its suggestions when the
  ``always_suggest`` option was enabled `#102`_

WebSearch package
------------------
* Made the ``{plugin_name}`` format field less confusing (i.e. ``WebSearch``
  instead of ``WebSearch.WebSearch``)

Documentation
-------------
* Added the ``How to support the project?`` question to the :doc:`faq` list
* Added the ``Is it open source?`` question to the :doc:`faq` list
* Added the ``Current Developments`` section in main page
* Added new :doc:`contributions`: ``KiTTY``, ``Calc`` and ``Integrated Patches``
* Improved :doc:`packages/calc` chapter
* Added social buttons
* Corrections

API
---
* **Package Naming** rules are stricter
* Added the :py:meth:`keypirinha.Plugin.friendly_name` method
* :py:meth:`keypirinha.Plugin.name` has been deprecated in favor of
  :py:meth:`keypirinha.Plugin.full_name`
* :py:meth:`keypirinha.Plugin.package_name` has been deprecated in favor of
  :py:meth:`keypirinha.Plugin.package_full_name`
* :py:func:`keypirinha_util.read_link` also returns the ``show_cmd`` and
  ``icon_location`` properties
* :py:func:`keypirinha_util.shell_execute` has been refactored to handle the
  case where the ``terminal_cmd`` itself is a shell link and to automatically
  guess the ``working_dir`` value in case none has been specified `#101`_
* Fixed a rare bug that could occur in
  :py:func:`keypirinha_util.execute_default_action` in case the call to
  :py:func:`keypirinha_util.shell_execute` failed
* Added the ``unquote`` parameter to the :py:meth:`keypirinha.Settings.get`,
  :py:meth:`keypirinha.Settings.get_stripped`,
  :py:meth:`keypirinha.Settings.get_enum` and
  :py:meth:`keypirinha.Settings.get_mapped` methods.
* Fixed: :py:meth:`keypirinha.Settings.get_enum` and
  :py:meth:`keypirinha.Settings.get_mapped` would not always match a valid value
  when the ``case_sensitive`` argument was ``True``
* Improved documentation of :py:class:`keypirinha.Settings`


v2.8 - 2016-07-11
=================

Application
-----------
* Fixed a bug that prevented the results to be displayed when the
  ``retain_last_search`` option was enabled `#88`_
* Added the ability to erase all the references of a package from history by
  selecting a result item and clicking the dedicated action in its contextual
  menu (mouse only; documentation updated) `#65`_
* The ``show_history_hits`` setting does not depend on ``show_scores`` anymore
  so items hits counts can be shown without having to enable the ``show_scores``
  option as well `#84`_
* Added the ``KNOWNFOLDER_...`` predefined variables to configuration
  files (``[var] section``).
  They may come handy for some the ``Apps`` and ``FileBrowser`` packages at
  least.
  See the :doc:`configuration` chapter for more info.

Bookmarks package
-----------------
* Firefox's padding bookmarks are now filtered out `#66`_

FileBrowser package
-------------------
* Fixed: typing ``C:\W`` would lead to an empty results list instead of
  returning at least a ``C:\Windows`` item for example `#81`_

WebSearch package
-----------------
* Search sites do not require argument anymore. If no argument is provided by
  the user, the guessed home address of the site will be launched instead of the
  provided ``url``, unless a ``home_url`` setting (**new**) has been
  specified `#85`_
* Pre-defined search sites can now be all disabled at once using the new
  ``enable_predefined_sites`` setting (`#57`_).
  **Note** that the section name of pre-defined sites is now
  ``predefined_site/`` instead of ``site/``.
* A single search site (pre-defined or not) can now be enabled/disabled using
  the new ``enable`` boolean setting
* Added the ``Python3 Mod`` predefined site

Documentation
-------------
* Added the :doc:`contributions` chapter that references available third-party
  packages and patches to the official packages `#82`_

API
---
* ``Plugin.create_error_item`` now copies the content of the ``short_desc``
  argument if ``label`` is empty. Items with an empty ``label`` are filtered out
  by the application and the created ``ERROR`` item would not be displayed.
* Corrected a potential bug in ``Settings.get_multiline`` when the returned
  fallback value was modified by the caller, then re-used (due to Python's
  "mutable default arguments")


v2.7 - 2016-07-03
=================

Application
-----------
* LaunchBox: item's ``data_bag`` property is now also printed in the Console
  when ``Alt+Enter`` is pressed
* ``Ctrl+Backspace`` conventional shortcut to erase the previously typed word in
  an edit control is now supported by the LaunchBox and the Console `#77`_

Apps package
------------
* Fixed a bug that occurred when a line in ``extra_paths`` was containing only
  a GUID (i.e. format ``::{guid}``)

Everything package
------------------
* Now takes advantage of the 'browse directory as you type' feature introduced
  with the ``FileBrowser`` package. After a search via ``Everything`` **and**
  once a directory item has been selected, it can be browsed using the ``Tab``
  key.

FileBrowser package
-------------------
* A new package that allows file browsing as you type (request `#32`_).
  More info available in documentation and configuration file.

API
---
* Embedded Python interpreter upgraded from 3.5.1 to 3.5.2
* Signature of ``Plugin.on_suggest`` has changed, refer to the documentation for
  more information. **This change breaks retro-compatibility.**
* Corrected ``GUID.__init__``, ``get_known_folder_path`` and the declaration
  of ``shell32.SHGetKnownFolderPath`` from the ``keypirinha_wintypes`` site
  module


v2.6.1 - 2016-06-10
===================

API
---
* Fixed: the content of the ``CatalogItem.data_bag`` property was not copied by
  the ``CatalogItem.clone`` method `#69`_


v2.6 - 2016-05-30
=================

Application
-----------
* Configuration is now reloaded if and only if at least one value has changed
  (previously, it was always reloaded when a change notification was pushed by
  the file system). This helps preventing the catalog to be updated because of
  modifications to comments or blank lines for example.
  This also applies to packages configuration.
* For the same reasons, the detection of modifications to the environment
  variables has been improved.

API
---
* Replaced ``Plugin.on_config_changed`` and ``Plugin.on_env_changed`` methods by
  ``Plugin.on_events``. **This change breaks retro-compatibility.**
* Added the ``show`` parameter to :py:func:`keypirinha_util.shell_execute`
  `#68`_


v2.5.6 - 2016-05-10
===================

Application
-----------
* Fixed: the `Internal` package was still loaded on startup despite being
  specified in the ``ignored_packages`` list `#59`_
* The ``ignored_packages`` setting is more flexible by allowing the ``<all>``
  value and the ``-`` and ``+`` operators
* Disabled the auto-repeat flag of every hotkeys to avoid trouble
* Rules for package naming are slightly more strict. See the :doc:`packages`
  chapter for more info
* Minimum **auto**-width of the LaunchBox is 600 pixels in case 1/3 of the
  screen width is less than that
* Log file is now machine specific and is named accordingly.
  Old "Keypirinha.log" file can be deleted manually (not done by Keypirinha)

TaskSwitcher package
--------------------
* Added the ``item_label`` setting `#54`_
* Added the ``always_suggest`` setting

Documentation
-------------
* Added the :doc:`custom-catalog` chapter `#57`_
* Corrections here and there


v2.5.5 - 2016-04-26
===================

Bookmarks package
-----------------
* Fixed a bug that prevented bookmarks to be extracted in some cases `#55`_

API
---
* Corrected the :py:func:`keypirinha_util.chardet_open` function due to
  issue `#55`_


v2.5.4 - 2016-04-23
===================

WinSCP package
--------------
* Fixed a CPU-eating bug that occurred while listing the configured sessions of
  WinSCP from the registry `#48`_


v2.5.3 - 2016-04-22
===================

**CAUTION**
-----------
* The type of the ``hide_on_focus_lost`` setting has changed to allow a more
  fine-grained tweaking. While effort has been made to keep retro-compatibility,
  please ensure your existing configuration complies to this modification.
* If at least one of your ``geometry`` settings is set to ``persistent``, you
  may have to manually reposition the window(s) the first time you start this
  new version due to the fix of issue `#39`_.

Application
-----------
* Fixed: icons of remote files are now displayed properly `#20`_
* Fixed: dragging the LaunchBox by its icon in maximized mode was resulting in
  an unexpected behavior `#47`_
* Fixed: made persistent geometry and more generally, application state,
  user AND machine-specific `#39`_
* Added the ``space_as_tab`` setting `#49`_
* Added the :kbd:`Shift+Alt+Enter` shortcut to the LaunchBox to directly invoke
  the Shell "Properties" dialog of the selected FILE item.
* The ``hotkey_run`` and ``hotkey_console`` settings accept new special keys and
  combinations. A message dialog also pops up in case of malformed value `#46`_
* The ``hide_on_focus_lost`` setting is more flexible
* Application is more verbose about malformed configuration values (console)
  instead of just silently falling back to hard-coded default

Bookmarks package
-----------------
* Try to automatically detect the text encoding of some files the plugins need
  to read from Chrome, Firefox and others `#51`_

API
---
* Added the :py:func:`keypirinha_util.chardet_open` function
* Added the :py:func:`keypirinha_util.chardet_slurp` function
* :py:func:`keypirinha_util.slurp_text_file` function is deprecated

Documentation
-------------
* Added the "Clear the history" section in the :doc:`first` chapter
* Corrections here and there


v2.5.2 - 2016-04-16
===================

Application
-----------
* Fixed handling of the ``show_on_taskbar`` setting `#43`_
* Added the ``escape_always_closes`` setting `#41`_
* LaunchBox can now be closed with :kbd:`Shift+Esc`

Documentation
-------------
* Added the :doc:`keyboard` chapter to list the available shortcuts
* Added the "Drag and Drop" section in the :doc:`first` chapter
* Typo corrections


v2.5.1 - 2016-04-14
===================

URL package
-----------
* Corrected handling of IP addresses and any URL not explicitly prefixed with a
  scheme `#40`_


v2.5 - 2016-04-13
=================

Application
-----------
* **New package:** :doc:`packages/url`
* Fixed: the LaunchBox and Console windows now give back the focus to the
  previous application/window when closed `#37`_
* The LaunchBox can now be maximized by hitting :kbd:`Alt+X` or standard
  :kbd:`Win+Up` combination (**toggle**). Double-click also works.
  See the :ref:`first-maximize` documentation section.
* Added the ``hide_on_focus_lost`` setting `#34`_
* Added the ``retain_last_search`` setting `#35`_
* ERROR items have been implemented.
  Keypirinha can now display error messages from the plugins directly to the
  results list so the user can have a direct feedback on what's going on in some
  cases. Note that the Console remains the best source of information to track
  down issues.
  Best example for now is the ``=`` item of the ``Calc`` package (try typing an
  invalid expression like ``2+``).
* The LaunchBox now supports drag-and-drop operations:

  - A file can be dropped to the edit box so its full path is inserted
  - FILE items can be dragged out of the results list and be copied/linked to
    the Windows Explorer or any other application that accepts drops of Shell
    items
  - URL, CMDLINE, EXPRESSION and ERROR items can also be dragged out and their
    content (i.e. the *target* property) will be copied to the drop destination.
    For example, you could drop a URL item to your web browser.

* In the LaunchBox, the :kbd:`Alt+Enter` combination allows to show up the
  properties of the currently selected item.
* User can now press :kbd:`Ctrl+Space` or :kbd:`Shift+Space` during the
  **initial** search to force include a space character instead of switching to
  the next step.
* Improved speed when merging a large list of suggestions from plugins

Calc package
------------
* Added support for the left-shift and right-shift operators (``<<`` and
  ``>>``).
* Added the ``always_evaluate`` setting `#38`_

Everything package
------------------
* Full support of Everything's search syntax `#27`_
* Added the ``Regex Search`` item to allow a search based on regular expression
* Fixed: the list of returned results was not always complete in case Everything
  was not fast enough `#36`_
* Fixed: extra arguments could not be added to items that had been executed
  already (Everything items only)

WebSearch package
-----------------
* Added ``Bing Maps``, ``Google Maps`` and ``OpenStreetMaps`` search sites in
  the default configuration file.

API
---
* Added optional argument ``wait_seconds`` to
  :py:meth:`keypirinha.Plugin.should_terminate` and
  :py:meth:`keypirinha.should_terminate`
* Added :py:const:`keypirinha.ItemCategory.ERROR`.
  ``ERROR`` items are highlighted in the results list and cannot be executed.
* Added :py:meth:`keypirinha.Plugin.create_error_item`
* Added the optional parameters ``match_method`` and ``sort_method`` to
  :py:meth:`keypirinha.Plugin.set_suggestions`
* Added the ``data_bag`` property to :py:class:`keypirinha.CatalogItem` to allow
  plugins to associate arbitrary data to a specific item.
  **Modified** :py:meth:`keypirinha.Plugin.create_item` and
  :py:meth:`keypirinha.Plugin.create_error_item` accordingly.
  **Added** the :py:meth:`keypirinha.CatalogItem.data_bag` and
  :py:meth:`keypirinha.CatalogItem.set_data_bag` methods.
* Added the :py:func:`keypirinha_util.shell_url_scheme_to_command` function to
  find the application associated with a given URL scheme by the system; and the
  location of its default icon.


v2.4 - 2016-03-24
=================

**CAUTION**
-----------
* The default value of the ``launch_at_startup`` setting has been changed from
  ``yes`` to ``no`` to be less invasive. You may need to update your
  configuration if you want Keypirinha to keep being launched at startup.
* WebSearch package: the default value of the ``new_window`` setting in the
  ``[defaults]`` section has been changed from ``yes`` to ``no`` to comply to
  default system preferences.

Added
-----
* The *Reload Configuration* command and menu to reload all configuration files
  (application and plugins), and to clear the runtime icons cache
* Non-existent files referenced by items in the history are now filtered out
  from search results, but **kept** in history (as it was the case already).
  Related setting: ``exclude_nonexistent_remote_files``.
* Docs: some questions in the :doc:`faq` chapter

Fixed
-----
* The *new_window* and *inognito/private_mode* settings (global and
  plugin-specific) where not working when Firefox was the system's default web
  browser `#25`_
* LaunchBox: web icons (Bookmarks, WebSearch, ... items) are now refreshed
  properly when the ``web_browser`` setting is changed `#26`_
* Apps package: made ``extra_paths``, env ``PATH`` and *Start Menu* scans more
  bullet-proof in case an unreadable file/folder gets on its way (`#19`_,
  `#29`_)
* Bookmarks: Firefox bookmarks provider could not read Firefox's
  ``profiles.ini`` file when its nomenclature format was not exactly the
  expected one `#30`_

Changed
-------
* LaunchBox: last executed action is now **pre-selected** in the ACTIONS list.
  If user skips the ACTIONS list, item will be executed with the default action.
* The default value of the ``launch_at_startup`` setting has been changed from
  ``yes`` to ``no`` to be less invasive.
* WebSearch package: the default value of the ``new_window`` setting in the
  ``[defaults]`` section has been changed from ``yes`` to ``no`` to comply to
  default system preferences.
* Minor corrections and improvements

API: Changed
------------
* :py:func:`keypirinha_util.raise_winerror` accepts a new optional ``msg``
  argument to override system's default message
* :py:func:`keypirinha_util.scan_directory` raises :py:exc:`OSError` instead
  of :py:exc:`IOError` to comply to Python 3.3 changes
* :py:func:`keypirinha_util.scan_directory` accepts new flag ``ABORT_ON_ERROR``


v2.3 - 2016-03-22
=================

**WARNING:** This version breaks compatibility of the
:py:meth:`keypirinha.Plugin.on_suggest` API with previous versions. If you are a
plugin developer or if you have modified the shipped packages, please ensure to
update your code before starting the application. Otherwise, just follow the
Install/Update instructions from the documentation.

Added
-----
* **New package:** Everything (query `Everything`_ to search files and folders
  from Keypirinha).
* Docs: the :doc:`first` chapter has been stuffed with features that were
  undocumented so far.
* ``geometry`` settings in the ``[gui]`` and ``[console]`` sections. Note that
  due to this addition, default behavior **has changed** from previous release
  (i.e. from ``persistent`` to ``auto``)
* ``web_browser``, ``web_browser_new_window`` and
  ``web_browser_private_mode`` global settings `#12`_
* Bookmarks package: ``force_new_window``, ``bookmarks_files``, ``places_files``
  and ``favorites_dirs`` settings
* WebSearch package: *Metacritic* and *MSDN* sites in default configuration
* LaunchBox: the status bar shows the name of the owner package of the currently
  selected item

Fixed
-----
* Application was failing to launch if the value of an environment variable had
  a single dollar sign in it `#14`_
* The default text editor was launched too quickly, which could make its taskbar
  buttons not to be in order.
* The windows of the default text editor were not positioned properly on the
  screen when there were 3 or more configuration files to edit.

Changed
-------
* Drastically improved the speed of the internal logger in case of flooding
* Minor corrections, optimizations and improvements
* Docs: corrections and added some screen shots
* TaskSwitcher package: item is now kept in history, without its arguments
* Support chat room has moved

API: Changed
------------
* :py:meth:`keypirinha.Plugin.on_suggest` (**compatibility break**)


v2.2 - 2016-03-10
=================

Added
-----
* Bookmarks package: support for the Vivaldi web browser

Fixed
-----
* Restored compatibility with Windows 7 (Vista support dropped) `#13`_
* Detection of system's default web browser was incorrect on Windows 10
  (impacted packages: Bookmarks and WebSearch) `#11`_
* Bookmarks package: Firefox provider was making the plugin to fail in case user
  profile was not found.


v2.1 - 2016-03-09
=================

Added
-----
* **New package:** Bookmarks (supports Chrome, Firefox and Internet Explorer)
* Position and size of the LaunchBox and the Console window are now persistent
  `#2`_
* ``always_on_top`` setting `#1`_
* ``max_height`` setting
* *Show Change Log* menu item and its *ChangeLog* catalog item
* *Online Documentation* menu item and the *Online Documentation* and
  *Online Help* (alias) catalog items
* Apps package: ``scan_start_menu`` and ``scan_env_path`` settings `#4`_
* Docs: *Update Procedure* section
* Docs: *Change Log* section
* Docs: *Credits* section

Changed
-------
* GUI: Improved readability by brightening default text colors `#6`_
* Calc package: the ``=`` item is not kept in History anymore

API: Added
----------
* :py:func:`keypirinha.exe_path`
* :py:func:`keypirinha.user_config_dir`
* :py:func:`keypirinha.package_cache_dir`
* :py:meth:`keypirinha.Plugin.id`
* :py:meth:`keypirinha.CatalogItem.valid`

API: Fixed
----------
* :py:func:`keypirinha.installed_package_dir` `#8`_
* :py:meth:`keypirinha.Plugin.create_action` was missing the ``data_bag``
  parameter `#7`_
* :py:meth:`keypirinha.Plugin.set_actions` and
  :py:meth:`keypirinha.Plugin.clear_actions` (due to `#7`_)
* :py:meth:`keypirinha.Plugin.get_package_cache_path` `#9`_

API: Deprecated
---------------
* :py:func:`keypirinha.packages_path` and :py:func:`keypirinha.package_path` are
  deprecated in favor of :py:func:`keypirinha.live_package_dir` to avoid
  confusion


v2.0 - 2016-03-01
=================
* First public release


v0 - 2013-05-21
===============
* Development started



.. _Keypirinha: http://keypirinha.com
.. _Everything: http://www.voidtools.com
.. _#1: https://github.com/Keypirinha/Keypirinha/issues/1
.. _#2: https://github.com/Keypirinha/Keypirinha/issues/2
.. _#4: https://github.com/Keypirinha/Keypirinha/issues/4
.. _#6: https://github.com/Keypirinha/Keypirinha/issues/6
.. _#7: https://github.com/Keypirinha/Keypirinha/issues/7
.. _#8: https://github.com/Keypirinha/Keypirinha/issues/8
.. _#9: https://github.com/Keypirinha/Keypirinha/issues/9
.. _#11: https://github.com/Keypirinha/Keypirinha/issues/11
.. _#12: https://github.com/Keypirinha/Keypirinha/issues/12
.. _#13: https://github.com/Keypirinha/Keypirinha/issues/13
.. _#14: https://github.com/Keypirinha/Keypirinha/issues/14
.. _#19: https://github.com/Keypirinha/Keypirinha/issues/19
.. _#20: https://github.com/Keypirinha/Keypirinha/issues/20
.. _#25: https://github.com/Keypirinha/Keypirinha/issues/25
.. _#26: https://github.com/Keypirinha/Keypirinha/issues/26
.. _#27: https://github.com/Keypirinha/Keypirinha/issues/27
.. _#29: https://github.com/Keypirinha/Keypirinha/issues/29
.. _#30: https://github.com/Keypirinha/Keypirinha/issues/30
.. _#32: https://github.com/Keypirinha/Keypirinha/issues/32
.. _#34: https://github.com/Keypirinha/Keypirinha/issues/34
.. _#35: https://github.com/Keypirinha/Keypirinha/issues/35
.. _#36: https://github.com/Keypirinha/Keypirinha/issues/36
.. _#37: https://github.com/Keypirinha/Keypirinha/issues/37
.. _#38: https://github.com/Keypirinha/Keypirinha/issues/38
.. _#39: https://github.com/Keypirinha/Keypirinha/issues/39
.. _#40: https://github.com/Keypirinha/Keypirinha/issues/40
.. _#41: https://github.com/Keypirinha/Keypirinha/issues/41
.. _#43: https://github.com/Keypirinha/Keypirinha/issues/43
.. _#45: https://github.com/Keypirinha/Keypirinha/issues/45
.. _#46: https://github.com/Keypirinha/Keypirinha/issues/46
.. _#47: https://github.com/Keypirinha/Keypirinha/issues/47
.. _#48: https://github.com/Keypirinha/Keypirinha/issues/48
.. _#49: https://github.com/Keypirinha/Keypirinha/issues/49
.. _#50: https://github.com/Keypirinha/Keypirinha/issues/50
.. _#51: https://github.com/Keypirinha/Keypirinha/issues/51
.. _#54: https://github.com/Keypirinha/Keypirinha/issues/54
.. _#55: https://github.com/Keypirinha/Keypirinha/issues/55
.. _#57: https://github.com/Keypirinha/Keypirinha/issues/57
.. _#59: https://github.com/Keypirinha/Keypirinha/issues/59
.. _#65: https://github.com/Keypirinha/Keypirinha/issues/65
.. _#66: https://github.com/Keypirinha/Keypirinha/issues/66
.. _#68: https://github.com/Keypirinha/Keypirinha/issues/68
.. _#69: https://github.com/Keypirinha/Keypirinha/issues/69
.. _#70: https://github.com/Keypirinha/Keypirinha/issues/70
.. _#73: https://github.com/Keypirinha/Keypirinha/issues/73
.. _#77: https://github.com/Keypirinha/Keypirinha/issues/77
.. _#81: https://github.com/Keypirinha/Keypirinha/issues/81
.. _#82: https://github.com/Keypirinha/Keypirinha/issues/82
.. _#84: https://github.com/Keypirinha/Keypirinha/issues/84
.. _#85: https://github.com/Keypirinha/Keypirinha/issues/85
.. _#88: https://github.com/Keypirinha/Keypirinha/issues/88
.. _#89: https://github.com/Keypirinha/Keypirinha/issues/89
.. _#93: https://github.com/Keypirinha/Keypirinha/issues/93
.. _#94: https://github.com/Keypirinha/Keypirinha/issues/94
.. _#96: https://github.com/Keypirinha/Keypirinha/issues/96
.. _#97: https://github.com/Keypirinha/Keypirinha/issues/97
.. _#98: https://github.com/Keypirinha/Keypirinha/issues/98
.. _#101: https://github.com/Keypirinha/Keypirinha/issues/101
.. _#102: https://github.com/Keypirinha/Keypirinha/issues/102
.. _#104: https://github.com/Keypirinha/Keypirinha/issues/104
.. _#106: https://github.com/Keypirinha/Keypirinha/issues/106
.. _#107: https://github.com/Keypirinha/Keypirinha/issues/107
.. _#111: https://github.com/Keypirinha/Keypirinha/issues/111
