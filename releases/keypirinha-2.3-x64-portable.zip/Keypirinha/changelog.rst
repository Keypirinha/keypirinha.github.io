Change log of `Keypirinha`_


v2.3 - 2016-03-22
=================

**WARNING:** This version breaks compatibility of the
:py:meth:`keypirinha.Plugin.on_suggest` API with previous versions. If you are a
plugin developer or if you have modified the shipped packages, please ensure to
update your code before starting the application. Otherwise, just follow the
Install/Update instructions from the documentation.

Added
-----
* **New official package**: Everything (query `Everything`_ to search files and
  folders from Keypirinha).
* Docs: the :doc:`first` chapter has been stuffed with features that were
  undocumented so far.
* ``geometry`` settings in the ``[gui]`` and ``[console]`` sections. Note that
  due to this addition, default behavior **has changed** from previous release
  (i.e. from ``persistent`` to ``auto``)
* ``web_browser``, ``web_browser_new_window`` and
  ``web_browser_private_mode`` global settings `#12`_
* Bookmarks package: ``force_new_window``, ``bookmarks_files``, ``places_files``
  and ``favorites_dirs`` settings
* WebSearch package: *Metacritic* and *MSDN* sites in default configuration
* LaunchBox: the status bar shows the name of the owner package of the currently
  selected item

Fixed
-----
* Application was failing to launch if the value of an environment variable had
  a single dollar sign in it `#14`_
* The default text editor was launched too quickly, which could make its taskbar
  buttons not to be in order.
* The windows of the default text editor were not positioned properly on the
  screen when there were 3 or more configuration files to edit.

Changed
-------
* Drastically improved the speed of the internal logger in case of flooding
* Minor corrections, optimizations and improvements
* Docs: corrections and added some screen shots
* TaskSwitcher package: item is now kept in history, without its arguments
* Support chat room has moved

API: Changed
------------
* :py:meth:`keypirinha.Plugin.on_suggest` (**compatibility break**)


v2.2 - 2016-03-10
=================

Added
-----
* Bookmarks package: support for the Vivaldi web browser

Fixed
-----
* Restored compatibility with Windows 7 (Vista support dropped) `#13`_
* Detection of system's default web browser was incorrect on Windows 10
  (impacted packages: Bookmarks and WebSearch) `#11`_
* Bookmarks package: Firefox provider was making the plugin to fail in case user
  profile was not found.


v2.1 - 2016-03-09
=================

Added
-----
* **New official package**: Bookmarks (supports Chrome, Firefox and Internet
  Explorer)
* Position and size of the LaunchBox and the Console window are now persistent
  `#2`_
* ``always_on_top`` setting `#1`_
* ``max_height`` setting
* *Show Change Log* menu item and its *ChangeLog* catalog item
* *Online Documentation* menu item and the *Online Documentation* and
  *Online Help* (alias) catalog items
* Apps package: ``scan_start_menu`` and ``scan_env_path`` settings `#4`_
* Docs: *Update Procedure* section
* Docs: *Change Log* section
* Docs: *Credits* section

Changed
-------
* GUI: Improved readability by brightening default text colors `#6`_
* Calc package: the ``=`` item is not kept in History anymore

API: Added
----------
* :py:func:`keypirinha.exe_path`
* :py:func:`keypirinha.user_config_dir`
* :py:func:`keypirinha.package_cache_dir`
* :py:meth:`keypirinha.Plugin.id`
* :py:meth:`keypirinha.CatalogItem.valid`

API: Fixed
----------
* :py:func:`keypirinha.installed_package_dir` `#8`_
* :py:meth:`keypirinha.Plugin.create_action` was missing the ``data_bag``
  parameter `#7`_
* :py:meth:`keypirinha.Plugin.set_actions` and
  :py:meth:`keypirinha.Plugin.clear_actions` (due to `#7`_)
* :py:meth:`keypirinha.Plugin.get_package_cache_path` `#9`_

API: Deprecated
---------------
* :py:func:`keypirinha.packages_path` and :py:func:`keypirinha.package_path` are
  deprecated in favor of :py:func:`keypirinha.live_package_dir` to avoid
  confusion


v2.0 - 2016-03-01
=================
* First public release


v0 - 2013-05-21
===============
* Development started



.. _Keypirinha: http://keypirinha.com
.. _Everything: http://www.voidtools.com
.. _#1: https://github.com/Keypirinha/Keypirinha/issues/1
.. _#2: https://github.com/Keypirinha/Keypirinha/issues/2
.. _#4: https://github.com/Keypirinha/Keypirinha/issues/4
.. _#6: https://github.com/Keypirinha/Keypirinha/issues/6
.. _#7: https://github.com/Keypirinha/Keypirinha/issues/7
.. _#8: https://github.com/Keypirinha/Keypirinha/issues/8
.. _#9: https://github.com/Keypirinha/Keypirinha/issues/9
.. _#11: https://github.com/Keypirinha/Keypirinha/issues/11
.. _#12: https://github.com/Keypirinha/Keypirinha/issues/12
.. _#13: https://github.com/Keypirinha/Keypirinha/issues/13
.. _#14: https://github.com/Keypirinha/Keypirinha/issues/14
